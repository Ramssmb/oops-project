import sqlite3

conn = sqlite3.connect("database.db")
c = conn.cursor()

# Add item_name column if not exists
try:
    c.execute("ALTER TABLE transactions ADD COLUMN item_name TEXT;")
    print("Added item_name column.")
except:
    print("item_name already exists.")

# Add meal_type column if not exists
try:
    c.execute("ALTER TABLE transactions ADD COLUMN meal_type TEXT;")
    print("Added meal_type column.")
except:
    print("meal_type already exists.")

conn.commit()
conn.close()
print("Migration complete.")
