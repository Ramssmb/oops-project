import sqlite3
DB = 'database.db'
conn = sqlite3.connect(DB)
c = conn.cursor()
c.execute("""CREATE TABLE IF NOT EXISTS weekly_menu(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  day_of_week INTEGER NOT NULL,
  meal_type TEXT NOT NULL,
  item_name TEXT NOT NULL,
  price REAL NOT NULL,
  extra_id INTEGER
);""")
conn.commit()
conn.close()
print('weekly_menu table ensured.')
