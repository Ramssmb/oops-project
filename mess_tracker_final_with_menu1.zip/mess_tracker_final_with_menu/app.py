import os
from flask import Flask, render_template, request, redirect, url_for, flash, session, send_from_directory
from db import init_db, get_db
import datetime
from functools import wraps
from werkzeug.utils import secure_filename
from werkzeug.security import check_password_hash

UPLOAD_FOLDER = os.path.join('static', 'uploads')
ALLOWED_EXT = {'png','jpg','jpeg','gif'}

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev_secret_change_me")
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Admin credentials (env supported)
ADMIN_USER = os.environ.get('ADMIN_USER', 'admin')
ADMIN_PASS = os.environ.get('ADMIN_PASS', 'password123')  # fallback plain
ADMIN_PASS_HASH = os.environ.get('ADMIN_PASS_HASH')  # if provided, will be used

init_db()

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('admin_logged_in'):
            flash("Please sign in as admin to access that page.", "error")
            return redirect(url_for('login', next=request.path))
        return f(*args, **kwargs)
    return decorated

def student_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('student_id'):
            flash("Please sign in as a student to access that page.", "error")
            return redirect(url_for('student_login', next=request.path))
        return f(*args, **kwargs)
    return decorated

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.',1)[1].lower() in ALLOWED_EXT

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        user = request.form.get('username')
        pwd = request.form.get('password')
        valid = False
        if ADMIN_PASS_HASH:
            valid = (user == ADMIN_USER and check_password_hash(ADMIN_PASS_HASH, pwd))
        else:
            valid = (user == ADMIN_USER and pwd == ADMIN_PASS)
        if valid:
            session['admin_logged_in'] = True
            flash("Signed in as admin.")
            nxt = request.args.get('next') or url_for('index')
            return redirect(nxt)
        flash("Invalid credentials.", "error")
        return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('admin_logged_in', None)
    session.pop('student_id', None)
    flash("Logged out.")
    return redirect(url_for('index'))

@app.route('/student_login', methods=['GET','POST'])
def student_login():
    if request.method == 'POST':
        roll = request.form.get('roll_no')
        conn = get_db()
        c = conn.cursor()
        c.execute("SELECT id FROM students WHERE roll_no = ?", (roll,))
        r = c.fetchone()
        conn.close()
        if r:
            session['student_id'] = r[0]
            flash("Signed in as student.")
            nxt = request.args.get('next') or url_for('student_view', student_id=r[0])
            return redirect(nxt)
        flash("Student not found.", "error")
        return redirect(url_for('student_login'))
    return render_template('student_login.html')

@app.route('/upload/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/')
def index():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, name, roll_no, balance FROM students")
    students = c.fetchall()
    c.execute("SELECT id, name, price, IFNULL(image_url,'') FROM extras")
    extras = c.fetchall()
    conn.close()
    return render_template('dashboard.html', students=students, extras=extras, admin=session.get('admin_logged_in'), student_id=session.get('student_id'))

@app.route('/admin/add_student', methods=['GET','POST'])
@admin_required
def add_student():
    if request.method == 'POST':
        name = request.form.get('name')
        roll = request.form.get('roll_no')
        balance = float(request.form.get('balance') or 0)
        conn = get_db()
        c = conn.cursor()
        c.execute("INSERT INTO students(name, roll_no, balance) VALUES(?,?,?)", (name, roll, balance))
        conn.commit()
        conn.close()
        flash('Student added.')
        return redirect(url_for('index'))
    return render_template('add_student.html')

@app.route('/admin/add_extra', methods=['GET','POST'])
@admin_required
def add_extra():
    if request.method == 'POST':
        name = request.form.get('name')
        price = float(request.form.get('price') or 0)
        calories = float(request.form.get('calories') or 0)
        image_url = request.form.get('image_url') or ''
        file = request.files.get('image_file')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            uploads_dir = os.path.join(app.root_path, app.config.get('UPLOAD_FOLDER', 'static/uploads'))
            os.makedirs(uploads_dir, exist_ok=True)
            save_path = os.path.join(uploads_dir, filename)
            file.save(save_path)
            image_url = os.path.join('static', 'uploads', filename)
        conn = get_db()
        c = conn.cursor()
        c.execute("INSERT INTO extras(name, price, calories, image_url) VALUES(?,?,?,?)", (name, price, calories, image_url))
        conn.commit()
        conn.close()
        flash('Extra item added.')
        return redirect(url_for('index'))
    return render_template('add_extra.html')

@app.route('/transaction', methods=['POST'])
@admin_required
def transaction():
    student_id = int(request.form.get('student_id'))
    extra_id = int(request.form.get('extra_id'))
    qty = int(request.form.get('qty') or 1)
    date = datetime.datetime.now().isoformat(timespec='seconds')
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT price FROM extras WHERE id = ?", (extra_id,))
    price_row = c.fetchone()
    if not price_row:
        flash('Invalid extra selected.', 'error')
        conn.close()
        return redirect(url_for('index'))
    price = price_row[0]
    total = price * qty
    # fetch item name from extras
    c.execute("SELECT name FROM extras WHERE id = ?", (extra_id,))
    name_row = c.fetchone()
    item_name = name_row[0] if name_row else "Extra Item"

    c.execute("""
    INSERT INTO transactions(student_id, extra_id, qty, total, date, item_name, meal_type)
    VALUES(?,?,?,?,?,?,?)
""", (student_id, extra_id, qty, total, date, item_name, None))

    c.execute("UPDATE students SET balance = balance - ? WHERE id = ?", (total, student_id))
    conn.commit()
    conn.close()
    flash('Transaction recorded.')
    return redirect(url_for('index'))

# weekly menu admin pages
@app.route('/admin/menu')
@admin_required
def menu_list():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, day_of_week, meal_type, item_name, price, extra_id FROM weekly_menu ORDER BY day_of_week, meal_type")
    menu = c.fetchall()
    c.execute("SELECT id, name FROM extras")
    extras = {r[0]: r[1] for r in c.fetchall()}
    conn.close()
    return render_template('menu_list.html', menu=menu, extras=extras)

@app.route('/admin/menu/add', methods=['GET','POST'])
@admin_required
def menu_add():
    if request.method == 'POST':
        dow = int(request.form.get('day_of_week'))
        meal_type = request.form.get('meal_type')
        item_name = request.form.get('item_name')
        price = float(request.form.get('price') or 0)
        extra_id = request.form.get('extra_id') or None
        extra_id = int(extra_id) if extra_id else None
        conn = get_db()
        c = conn.cursor()
        c.execute("INSERT INTO weekly_menu(day_of_week, meal_type, item_name, price, extra_id) VALUES(?,?,?,?,?)",
                  (dow, meal_type, item_name, price, extra_id))
        conn.commit()
        conn.close()
        flash("Menu item added.")
        return redirect(url_for('menu_list'))
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, name FROM extras")
    extras = c.fetchall()
    conn.close()
    return render_template('menu_add.html', extras=extras)

@app.route('/admin/menu/delete/<int:menu_id>', methods=['POST'])
@admin_required
def menu_delete(menu_id):
    conn = get_db()
    c = conn.cursor()
    c.execute("DELETE FROM weekly_menu WHERE id = ?", (menu_id,))
    conn.commit()
    conn.close()
    flash("Menu item deleted.")
    return redirect(url_for('menu_list'))

@app.route('/add_meal', methods=['GET','POST'])
@admin_required
def add_meal():
    if request.method == 'POST':
        student_id = int(request.form.get('student_id'))
        meal_type = request.form.get('meal_type')
        date = request.form.get('date') or datetime.date.today().isoformat()
        # compute day_of_week
        dt = datetime.date.fromisoformat(date)
        dow = dt.weekday()
        conn = get_db()
        c = conn.cursor()
        c.execute("""SELECT id, item_name, price, extra_id
                     FROM weekly_menu
                     WHERE day_of_week = ? AND meal_type = ?
                     LIMIT 1""", (dow, meal_type))
        menu_row = c.fetchone()
        if not menu_row:
            c.execute("INSERT INTO daily_meals(student_id, date, meal_type) VALUES(?,?,?)",
                      (student_id, date, meal_type))
            conn.commit()
            conn.close()
            flash('Meal recorded (no menu price found).')
            return redirect(url_for('index'))

        menu_id, item_name, price, extra_id = menu_row
        # optional: check balance
        c.execute("SELECT balance FROM students WHERE id = ?", (student_id,))
        bal_row = c.fetchone()
        balance = bal_row[0] if bal_row else 0.0

        c.execute("INSERT INTO daily_meals(student_id, date, meal_type) VALUES(?,?,?)",
                  (student_id, date, meal_type))
        c.execute("""
    INSERT INTO transactions(student_id, extra_id, qty, total, date, item_name, meal_type)
    VALUES(?,?,?,?,?,?,?)
""", (student_id, extra_id, 1, price, date, item_name, meal_type))

        c.execute("UPDATE students SET balance = balance - ? WHERE id = ?", (price, student_id))
        conn.commit()
        conn.close()
        flash(f"Meal recorded: {item_name} charged ₹{price:.2f}.")
        return redirect(url_for('index'))

    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, name FROM students")
    students = c.fetchall()
    conn.close()
    return render_template('add_meal.html', students=students)

@app.route('/student/<int:student_id>')
def student_view(student_id):
    if not session.get('admin_logged_in') and session.get('student_id') and session.get('student_id') != student_id:
        flash('Access denied.', 'error')
        return redirect(url_for('index'))
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, name, roll_no, balance FROM students WHERE id = ?", (student_id,))
    student = c.fetchone()
    c.execute("""
    SELECT t.id, 
           t.item_name,
           t.qty,
           t.total,
           t.date,
           COALESCE(e.image_url, '') AS image_url,
           t.meal_type
    FROM transactions t
    LEFT JOIN extras e ON t.extra_id = e.id
    WHERE t.student_id = ?
    ORDER BY t.date DESC
    LIMIT 50
""", (student_id,))
    transactions = c.fetchall()


    conn.close()
    return render_template('student.html', student=student, transactions=transactions)

@app.route('/reports')
@admin_required
def reports():
    conn = get_db()
    c = conn.cursor()
    c.execute("SELECT id, name, roll_no, balance FROM students")
    students = c.fetchall()
    c.execute("""SELECT s.id, s.name, IFNULL(SUM(t.total),0) as spent
                 FROM students s LEFT JOIN transactions t ON s.id = t.student_id
                 GROUP BY s.id ORDER BY spent DESC""")
    spending = c.fetchall()
    conn.close()
    return render_template('reports.html', students=students, spending=spending)

if __name__ == '__main__':
    app.run(debug=True)
