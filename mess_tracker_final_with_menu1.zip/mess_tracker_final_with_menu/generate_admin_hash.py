from werkzeug.security import generate_password_hash
import sys
if len(sys.argv) < 2:
    print('Usage: python generate_admin_hash.py <password>')
else:
    print(generate_password_hash(sys.argv[1]))
