import sqlite3
DB_PATH = "database.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS students(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        roll_no TEXT UNIQUE,
        balance REAL DEFAULT 0
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS extras(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        price REAL,
        calories REAL,
        image_url TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS transactions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        extra_id INTEGER,
        qty INTEGER,
        total REAL,
        date TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS daily_meals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        student_id INTEGER,
        date TEXT,
        meal_type TEXT
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS weekly_menu(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        day_of_week INTEGER NOT NULL,
        meal_type TEXT NOT NULL,
        item_name TEXT NOT NULL,
        price REAL NOT NULL,
        extra_id INTEGER
    )""")
    conn.commit()
    conn.close()
